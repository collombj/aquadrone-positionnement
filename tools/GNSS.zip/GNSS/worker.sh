#!/bin/bash

python /home/pi/GNSS/receiver.py
